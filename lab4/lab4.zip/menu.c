/***************************************************/
/*FLLE NAME:menu.c                                  */
/*LANGUAGE:C                                       */
/*AUTHOR:SA17225073                                */
/***************************************************/
/*Revision Log:1017/10/14
 *
 */

#include"list.h"
#include<pthread.h>
#define SUCCESS 0
#define FAIL (-1)
#include<stdio.h>
#include<stdlib.h>
#define COM_LEN 128
#define DESC_LEN 1024
#define COM_NUM 10

typedef struct datanode
{
    tlinktablenode *pnext;
    char *cmd;
    char *desc;
    int (*func)();
}tdatanode;

tlinktable * head=NULL;

int help();
int add();
int sub();
int mul();
int divi();
int max();
int min();
int avg();
int mod();
int quit();


int add()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a+b);
    printf("\n");
    return 0;
}

int sub()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a-b);
    printf("\n");
    return 0;
}

int mul()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a*b);
    printf("\n");
    return 0;
}

int divi()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a/b);
    printf("\n");
    return 0;
}

int max()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a>b?a:b);
    printf("\n");
    return 0;
}

int min()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a<b?a:b);
    printf("\n");
    return 0;
}

int avg()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",(a+b)/2);
    printf("\n");
    return 0;
}

int mod()
{
    printf("enter 2 int numbers: ");
    int a,b;
    scanf("%d%d",&a,&b);
    printf("result is %d: ",a%b);
    printf("\n");
    return 0;
}

int quit()
{
    exit(0);
}

tdatanode * findcmd(tlinktable *head,char *cmd)
{
    tdatanode *pnode=(tdatanode *)getlinktablehead(head);

    while(pnode!=NULL)
    {
        if(strcmp(pnode->cmd,cmd)==0)
        {
            return pnode;
        }
        pnode=(tdatanode *)getlinktablenode(head,(tlinktablenode *)pnode);
    }
    return NULL;
}

int showcmd(tlinktable * head)
{
    tdatanode *pnode=(tdatanode *)getlinktablehead(head);

    while(pnode!=NULL)
    {
        printf("%-10s %-30s\n",pnode->cmd,pnode->desc);
        pnode=(tdatanode *)getlinktablenode(head,(tlinktablenode *)pnode);
    }
    return 0;
}

int help()
{
   return showcmd(head);
}

int Initmenudata(tlinktable **pplinktable)
{
    *pplinktable=createlinktable();
    tdatanode *pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="help";
    pnode->desc="this is a help list";
    pnode->func=help;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="add";
    pnode->desc="this is an add list";
    pnode->func=add;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="sub";
    pnode->desc="this is a sub list";
    pnode->func=sub;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="mul";
    pnode->desc="this is a mul list";
    pnode->func=mul;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="divi";
    pnode->desc="this is a divi list";
    pnode->func=divi;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="max";
    pnode->desc="this is a max list";
    pnode->func=max;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="min";
    pnode->desc="this is a min list";
    pnode->func=min;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="mod";
    pnode->desc="this is a mod list";
    pnode->func=mod;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="quit";
    pnode->desc="this is a quit list";
    pnode->func=quit;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    pnode=(tdatanode *)malloc(sizeof(tdatanode));
    pnode->cmd="version";
    pnode->desc="this version is 3.0";
    pnode->func=NULL;
    addlinktablenode(*pplinktable,(tlinktablenode *)pnode);
    return 0;
}


int main()
{   Initmenudata(&head);
    while(1)
    {
        char cmd[COM_LEN];
        printf("input a cmd number >");
        scanf("%s",cmd);
        tdatanode *p=findcmd(head,cmd);
        if(p==NULL)
        {
            printf("this is a wrong commmand\n");
            continue;
        }
        printf("%-10s %-30s\n",p->cmd,p->desc);
        if(p->func!=NULL)
        {
            p->func();
        }

    }
}
