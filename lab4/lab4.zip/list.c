#include"list.h"
#include<stdio.h>
#include<stdlib.h>
tlinktable * createlinktable()
{
    tlinktable *t=malloc(sizeof(tlinktable));
    t->phead=t->ptail=NULL;
    t->sumofnode=0;
    return t;
}

int deletelinktable(tlinktable *plinktable)
{
    free(plinktable);
    return 0;
}

int addlinktablenode(tlinktable *plinktable,tlinktablenode *pnode)
{
    if(plinktable->phead==NULL)
    {
        plinktable->phead=pnode;
        plinktable->ptail=pnode;
    }
    else
    {
        plinktable->ptail->next=pnode;
        plinktable->ptail=pnode;
    }
    plinktable->sumofnode++;
    plinktable->ptail->next=NULL;
    return 0;
}

int dellinktablenode(tlinktable *plinktable,tlinktablenode *pnode)
{
    tlinktablenode *t=malloc(sizeof(tlinktablenode));
    t->next=plinktable->phead;
    while(t->next!=pnode)
    {
        t=t->next;
    }
    t->next=pnode->next;
    plinktable->sumofnode--;

}

tlinktablenode * getlinktablehead(tlinktable *plinktable)
{
    return plinktable->phead;
}

tlinktablenode * getlinktablenode(tlinktable *plinktable,tlinktablenode *pnode)
{
    return pnode->next;
}
